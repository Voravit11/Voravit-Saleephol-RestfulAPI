import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// 🌐 Global
import "./styles/global.css";

// 🎮 Components
import "./styles/navbar.css";

// 📄 Pages
import "./styles/home.css";
import "./styles/market.css";
import "./styles/cart.css";
import "./styles/addProduct.css";
import "./styles/admin.css";
import "./styles/login.css";
import "./styles/register.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
