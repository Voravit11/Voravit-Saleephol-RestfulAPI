import { useState } from "react";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Market from "./pages/Market";
import Home from "./pages/Home";
import AddProduct from "./pages/AddProduct";
import AdminPanel from "./pages/AdminPanel";
import Cart from "./pages/Cart";

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("login");

  if (!user && page !== "register")
    return <Login setUser={setUser} setPage={setPage} />;

  if (page === "register") return <Register setPage={setPage} />;

  return (
    <>
      <Navbar setPage={setPage} setUser={setUser} user={user} />
      {page === "home" && <Home />}
      {page === "market" && <Market user={user} />}
      {page === "add" && <AddProduct user={user} />}
      {page === "admin" && <AdminPanel user={user} />}
      {page === "cart" && <Cart user={user} />}
    </>
  );
}
