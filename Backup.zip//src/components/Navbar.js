export default function Navbar({ setPage, setUser, user }) {
  return (
    <div className="navbar">
      <div className="nav-logo" onClick={() => setPage("home")}>
        🤖 Gundam Market
      </div>

      <div className="nav-actions">
        <button className="nav-btn" onClick={() => setPage("home")}>
          Home
        </button>
        <button className="nav-btn" onClick={() => setPage("market")}>
          Market
        </button>
        <button className="nav-btn" onClick={() => setPage("add")}>
          เพิ่มสินค้า
        </button>
        <button className="nav-btn cart" onClick={() => setPage("cart")}>
          🛒 ตะกร้า
        </button>

        {user?.role === "admin" && (
          <button className="nav-btn admin" onClick={() => setPage("admin")}>
            Admin
          </button>
        )}

        <button
          className="nav-btn logout"
          onClick={() => {
            setUser(null);
            setPage("login");
          }}
        >
          Logout
        </button>
      </div>
    </div>
  );
}
