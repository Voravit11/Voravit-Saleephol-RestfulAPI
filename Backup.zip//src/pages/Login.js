import { useState } from "react";
import { supabase } from "../lib/supabase";

export default function Login({ setUser, setPage }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const login = async () => {
    if (!username || !password) return alert("กรอกข้อมูลให้ครบ");

    const { data, error } = await supabase
      .from("users")
      .select("*")
      .eq("username", username)
      .single();

    if (!data) return alert("ไม่พบ username นี้ในระบบ");
    if (data.password !== password) return alert("password ไม่ถูกต้อง");

    setUser(data);

    if (data.role === "admin") {
      setPage("admin");
    } else {
      setPage("market");
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <h2 className="login-title">Login</h2>

        <div className="login-form">
          <input
            className="login-input"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <input
            className="login-input"
            placeholder="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button className="login-btn" onClick={login}>
            เข้าสู่ระบบ
          </button>

          <p className="login-register" onClick={() => setPage("register")}>
            ยังไม่มีบัญชี? <span>สมัครสมาชิก</span>
          </p>
        </div>
      </div>
    </div>
  );
}
