export default function Home() {
  return (
    <div className="page home">
      <h1>Gundam Marketplace</h1>
      <p>ตลาดซื้อขายโมเดลกันดัม</p>

      <div className="hero">
        <img src="https://co.lnwfile.com/_/co/_raw/yt/u9/0a.jpg" alt="Gundam" />
      </div>

      <div className="actions">
        <p>🔥 ศูนย์รวมโมเดลกันดัมมือหนึ่ง มือสอง</p>
        <p>⚡ ซื้อ - ขาย - แลกเปลี่ยน ได้ในที่เดียว</p>
      </div>
    </div>
  );
}
