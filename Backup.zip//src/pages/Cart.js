import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function Cart({ user }) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const { data } = await supabase
      .from("cart")
      .select("*, products(*)")
      .eq("user_id", user.id);

    setItems(data || []);
  };

  const del = async (id) => {
    await supabase.from("cart").delete().eq("id", id);
    load();
  };

  return (
    <div className="cart-page">
      <h2 className="cart-title">🛒 ตะกร้าสินค้า</h2>

      <div className="cart-list">
        {items.map((i) => (
          <div key={i.id} className="cart-card">
            <div className="cart-img-box">
              <img src={i.products.image_url} alt={i.products.name} />
            </div>

            <div className="cart-info">
              <div className="cart-name">{i.products.name}</div>
            </div>

            <button className="cart-del" onClick={() => del(i.id)}>
              ลบออก
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
