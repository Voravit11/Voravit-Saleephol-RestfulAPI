import { useState } from "react";
import { supabase } from "../lib/supabase";

export default function Register({ setPage }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const register = async () => {
    if (!username || !password) return alert("กรอกข้อมูลให้ครบ");

    const { data: exist } = await supabase
      .from("users")
      .select("id")
      .eq("username", username)
      .maybeSingle();

    if (exist) return alert("username ซ้ำ");

    const { error } = await supabase.from("users").insert([
      {
        username,
        password,
        role: "user",
      },
    ]);

    if (error) {
      console.log(error);
      alert("สมัครไม่สำเร็จ");
    } else {
      alert("สมัครสำเร็จ");
      setPage("login");
    }
  };

  return (
    <div className="register-page">
      <div className="register-card">
        <h2 className="register-title">Register</h2>

        <div className="register-form">
          <input
            className="register-input"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <input
            className="register-input"
            placeholder="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button className="register-btn" onClick={register}>
            สมัครสมาชิก
          </button>

          <p className="register-login" onClick={() => setPage("login")}>
            มีบัญชีแล้ว? <span>ไปหน้า Login</span>
          </p>
        </div>
      </div>
    </div>
  );
}
