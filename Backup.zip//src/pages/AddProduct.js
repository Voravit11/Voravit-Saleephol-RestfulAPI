import { useState } from "react";
import { supabase } from "../lib/supabase";

export default function AddProduct({ user }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const add = async () => {
    if (!name || !price || !imageUrl) return alert("กรอกให้ครบ");

    await supabase.from("products").insert([
      {
        name,
        price: Number(price),
        image_url: imageUrl,
        owner_id: user.id,
      },
    ]);

    alert("เพิ่มสินค้าแล้ว");
  };

  return (
    <div className="add-card">
      <h3 className="add-title">เพิ่มสินค้าใหม่</h3>

      <div className="add-form">
        <input
          className="add-input"
          placeholder="ชื่อสินค้า"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          className="add-input"
          placeholder="ราคา"
          type="number"
          onChange={(e) => setPrice(e.target.value)}
        />

        <input
          className="add-input"
          placeholder="ลิ้งรูป URL"
          onChange={(e) => setImageUrl(e.target.value)}
        />

        <button className="add-btn" onClick={add}>
          + เพิ่มสินค้า
        </button>
      </div>
    </div>
  );
}
