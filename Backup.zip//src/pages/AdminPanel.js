import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function Admin() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const { data } = await supabase.from("products").select("*");
    setProducts(data || []);
  };

  const del = async (id) => {
    await supabase.from("products").delete().eq("id", id);
    load();
  };

  return (
    <div className="admin-page">
      <h2 className="admin-title">Admin Panel</h2>

      <div className="admin-grid">
        {products.map((p) => (
          <div key={p.id} className="admin-card">
            <div className="admin-img-box">
              <img src={p.image_url} alt={p.name} />
            </div>

            <div className="admin-info">
              <div className="admin-name">{p.name}</div>
              <div className="admin-price">฿{p.price}</div>
            </div>

            <button className="admin-del" onClick={() => del(p.id)}>
              ลบสินค้า
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
