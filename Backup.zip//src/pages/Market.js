import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import "../styles/market.css";

export default function Market({ user }) {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState(""); // 🔍 search state

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const { data } = await supabase.from("products").select("*");
    setProducts(data || []);
  };

  const addToCart = async (product_id) => {
    await supabase.from("cart").insert([
      {
        user_id: user.id,
        product_id,
        qty: 1,
      },
    ]);
    alert("เพิ่มลงตะกร้าแล้ว");
  };

  const del = async (id) => {
    await supabase.from("products").delete().eq("id", id);
    load();
  };

  // 🔍 filter logic
  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="market-page">
      <h2 className="market-title">🛒 Marketplace</h2>

      {/* 🔍 SEARCH BAR */}
      <div className="market-search">
        <input
          type="text"
          placeholder="ค้นหาโมเดลกันดัม..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button>ค้นหา</button>
      </div>

      <div className="market-grid">
        {filteredProducts.map((p) => (
          <div key={p.id} className="market-card">
            <div className="market-img-box">
              <img src={p.image_url} alt={p.name} />
            </div>

            <div className="market-info">
              <h3 className="market-name">{p.name}</h3>
              <p className="market-price">฿{p.price}</p>
            </div>

            <div className="market-actions">
              <button
                className="market-btn cart-btn"
                onClick={() => addToCart(p.id)}
              >
                ใส่ตะกร้า
              </button>

              {(p.owner_id === user.id || user.role === "admin") && (
                <button
                  className="market-btn del-btn"
                  onClick={() => del(p.id)}
                >
                  ลบ
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
